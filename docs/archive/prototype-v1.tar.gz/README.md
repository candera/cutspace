# Cutspace

An interactive, local milling operating-envelope explorer. React + TypeScript + Vite; canvas heatmaps and SVG axes/contours. No backend, machine connection or account required.

## Run

Requires Node.js 22.18+ (or a current Node release) and npm. Tested here on Node 26.12.1.

```sh
cd ~/projects/cutspace
npm install
npm run dev
```

Open the local URL printed by Vite (normally http://127.0.0.1:5173). The server binds to loopback only.

```sh
npm test          # numerical reference, boundary, unit and edge-case checks
npm run build    # strict TypeScript check and production bundle
npm run preview  # serve the built production bundle locally
```

## Explore

- Click or drag either plot; they share one cutting point. The RPM/feed plot holds DOC/WOC fixed, while the DOC/WOC plot holds RPM/feed fixed.
- Focus a plot and use arrow keys; Shift changes the step from 1% to 5% of each axis. Numeric inputs and sliders are equivalent accessible controls. Numeric edits commit on blur or Enter; invalid entries reset, out-of-range values clamp.
- Switch color metrics: MRR, estimated spindle power, nominal feed per tooth (chip load), estimated static deflection or limiting constraint. Continuous metrics also support contour lines at 20/40/60/80% of the displayed scale. Both plots use the same linear scale, fitted to samples within the configured limits across both grids. Higher values outside the envelope saturate at the top color. If neither grid has a feasible sample, scaling falls back to the full grids. The legend updates with the setup.
- Bright regions pass all configured checks. Darkened regions exceed one or more checks; dashed white lines approximate the boundary. Constraint colors show the highest normalized ratio even inside the envelope, where it is only the nearest configured limit.
- Edit tool, material coefficient, machine curve and limit assumptions in the Setup panel. On narrow screens Setup follows the explorer. Collapsible sections expose model constants and thresholds.
- Export setup downloads JSON with inputs, outputs, model version and a caveat. There is no import or automatic persistence yet; reload or Reset restores the seed. Edits never command a machine.

## Scope and evidence labels

**This is a visualization prototype, not a cut recommendation or a safety assessment.** “Within modeled limits” means only that all configured ratios are ≤1. All default thresholds are unvalidated demonstration values. Tool breakage, workholding, machine compliance and chatter remain possible inside the displayed envelope.

- **Computed:** algebraic relationships from the specified geometry and kinematics (surface speed, feed/tooth, MRR).
- **Ideal geometry:** radial chip thinning and maximum chip thickness; no runout, eccentricity or edge effects.
- **Estimated:** power, torque, force, static deflection and available spindle output.
- **Unvalidated limits:** editable thresholds used to construct the envelope; not manufacturer recommendations.

The profile called **DMC2 Mini · illustrative** is a convenient user-editable name only. It contains **no verified DMC2 manufacturer specifications**. Its RPM range, feed limit, power and torque plateaus are all fictional starting assumptions. Power refers to mechanical output at the spindle, not electrical input or motor nameplate power. Replace the profile with measured or verified data before using it to inform machine work.

## Seed setup (all metric)

| Input | Initial value | Status |
|---|---:|---|
| Flat end mill diameter / flutes | 6 mm / 3 | Illustrative geometry |
| Stickout / usable flute length | 20 / 15 mm | Illustrative geometry |
| Tool modulus / effective stiffness | 600 GPa / 0.45 × solid circular section | Uncalibrated carbide assumptions |
| Work material | 6061 aluminum | Starting material; alloy/temper effects not modeled |
| Effective cutting force coefficient Kc | 1000 N/mm² | Illustrative, adjustable; not certified data |
| Power / force allowance | 1.25× / 1.3× | Conservative-intent multipliers, not proven bounds |
| Machine RPM bounds | 3000–18000 | Unvalidated placeholders |
| Maximum feed | 3000 mm/min | Unvalidated placeholder |
| Power / torque plateau | 250 W / 0.3 Nm | Unvalidated placeholders |
| Usable output | 75% | Leaves 25% reserve from the assumed curve |
| Chip-thickness band | 0.008–0.055 mm | Unvalidated demonstration thresholds |
| Deflection / surface-speed maximum | 25 µm / 450 m/min | Unvalidated demonstration thresholds |
| Selected RPM / feed / DOC / WOC | 10000 / 1200 mm/min / 3 mm / 1.2 mm | Demonstration point |

For that cut, computed speed is 188.50 m/min, feed/tooth 0.0400 mm, maximum chip thickness 0.0320 mm and MRR 4.32 cm³/min. Estimated power is 90 W, torque 0.08594 Nm and static deflection about 19.37 µm. The seed passes the configured checks; this is not experimental validation.

## Physics model, units and assumptions

The implementation lives in `src/model.ts` and has no UI dependencies. Symbols below use diameter D, stickout L, axial DOC ap, radial WOC ae in mm; spindle n in RPM; feed vf in mm/min; flute count z. Positive finite inputs are required by the model; the UI constrains them. Direct library callers must validate their own inputs.

### Geometry and material removal

```text
surface speed vc = π D n / 1000                           [m/min]
feed per tooth fz = vf / (n z)                           [mm/tooth]
MRR Q = ap ae vf / 1000                                  [cm³/min]
r = ae / D, 0 ≤ r ≤ 1
chip-thinning factor s = 2 √(r (1-r)) if r < 0.5, else 1
maximum chip thickness hmax = fz s                       [mm]
feed multiplier = 1 / s
```

The thinning formula follows the engagement angle of an ideal cylindrical cutter. Above half-diameter engagement the sweep includes the maximum chip thickness, so the factor stays at one (it does not fall back to zero during slotting). This is straight peripheral milling: no corner-radius, ball-nose, lead-angle, ramping or entry model. The feed multiplier is informational and **never automatically applies a feed increase**. Low-chip warnings use hmax rather than nominal fz. Zero WOC produces zero removal and an infinite low-chip ratio; displayed controls avoid zero.

### Power and torque

```text
estimated mechanical cutting power P = Q Kc / 60 × powerAllowance  [W]
estimated torque T = P × 60 / (2 π n)                              [Nm]
available power = min(Pplateau, Tplateau × 2 π n / 60) × usableFraction
```

The model uses an effective constant Kc and omits chip-thickness size effects, rake/helix dependence, lubrication, edge wear and changing material properties. The power allowance adds explicit margin. It does not imply a validated upper bound. The machine curve is a constant-torque region followed by a constant-power region. Its crossover follows from the two editable plateaus, not from a manufacturer motor speed. The curve is shown outside the allowed RPM range for illustration; RPM constraints separately exclude those cuts. Separate power and torque ratios are equivalent to comparing demand with the minimum of the two curve branches.

### Static tool deflection estimate

```text
engagement angle φ = acos(1 - 2r)                         [radians]
engaged teeth zEng = max(1, ceil(z φ / (2π)))
estimated lateral force F = Kc ap hmax zEng × forceAllowance  [N]
effective second moment I = stiffnessFactor × π D⁴ / 64   [mm⁴]
static tip deflection δ = F L³ / (3 E I) × 1000            [µm]
```

E is converted from GPa to N/mm² (×1000). Force conservatively sums peak tooth loads, then adds a force allowance. A reduced section stiffness and tip-applied load add further conservatism relative to a solid circular shank and distributed flute load. Neither proves an upper bound on real displacement: geometry, tooth phasing, holder compliance and dynamic response are missing. The integer engaged-tooth count can cause visible steps in the deflection map. This is deliberate and documented, not a stability lobe.

**No chatter prediction.** Static bending cannot establish chatter onset. It does not model modal stiffness, damping, regenerative effects, forced vibration, spindle bearings, machine frames, fixture stiffness, tool pullout, thermal growth, breakage or transient entry/exit loads.

### Envelope

The largest ratio is the limiting constraint. All must be ≤1:

- hmax / maxChip and minChip / hmax (the latter increases when the chip gets too thin).
- P / (powerPlateau × usableFraction).
- T / (torquePlateau × usableFraction).
- Deflection / deflectionLimit and surfaceSpeed / surfaceSpeedLimit.
- max(minRPM / n, n / maxRPM), and feed / machineFeedLimit.
- max(WOC / diameter, DOC / fluteLength, DOC / stickout).

Geometry thresholds are simple reach checks, not a collision or stiffness model. The grids deliberately extend beyond RPM/feed/DOC limits to make the boundary visible; radial WOC stays within one tool diameter. Grids sample 80×54 cell centers per panel. D3 marching-squares contours interpolate that field. A narrow feasible region can be missed; the selected-point calculation remains exact relative to these formulas. Axis endpoints at zero are display bounds; pointer selection clamps DOC/WOC to 0.01 mm and feed to 1 mm/min.

## Sources

These sources support the standard formula forms and qualitative principles, **not Cutspace's default coefficients or thresholds**:

- [Sandvik Coromant — Milling formulas and definitions](https://www.sandvik.coromant.com/en-gb/knowledge/machining-formulas-definitions/milling-formulas-definitions): speed, feed, MRR, net power and torque relationships.
- [Harvey Performance — How to Combat Chip Thinning](https://www.harveyperformance.com/in-the-loupe/combat-chip-thinning/): radial-engagement dependence and feed compensation.
- [MIT OpenCourseWare — Beam mechanics](https://live.ocw.mit.edu/courses/1-050-solid-mechanics-fall-2004/f9a4d5764b9b0f51ffaacbdf69f7aed8_emech10_04.pdf): linear-elastic cantilever bending.

## Extend

- `src/model.ts`: replace `availablePower` with an interpolated measured spindle-output curve; calibrate Kc against observed power; add tool-specific chip recommendations with source/provenance. Keep mechanical output separate from electrical input.
- Add actual flute cross-section properties, measured compliance, force directions and helix/engagement integration before refining static deflection. A chatter/stability model requires separate dynamics and validation; do not infer it from this static estimate.
- `src/plots.ts`: sampling ranges, shared color scale and contour geometry. Adaptive sampling or a boundary solver would better resolve narrow envelopes.
- `src/App.tsx`: setup controls, output labels, warnings, keyboard/pointer selection, JSON export and model notes. Preset persistence/import or imperial display could be added here.
- `src/styles.css`: responsive application layout. Fonts optionally load from Google Fonts; system fonts take over offline. No other runtime service or API is used.
- `tests/model.test.ts` and `tests/plots.test.ts`: reference numerical cases, power/torque crossover, chip thinning, zero engagement, cubic bending scaling, constraint crossings finite-grid checks, linked selection mapping, contours and empty-envelope scaling. Run them after changing units or physics.

## Current limitations

This prototype intentionally omits optimization, G-code, machine control, automatic feed compensation, saving/importing profiles, custom material catalogs and experimentally validated cutting recommendations. Changing a tool diameter clamps WOC to the new diameter. RPM minimum/maximum and chip minimum/maximum are kept ordered. The UI uses metric units throughout. The full setup is held in memory until reset/reload; export JSON if you want to preserve an experiment.
