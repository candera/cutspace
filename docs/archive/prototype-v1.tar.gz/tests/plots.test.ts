import test from 'node:test';
import assert from 'node:assert/strict';
import { cloneDefaults } from '../src/model.ts';
import { cutAt, gridFor, NX, NY, scaleMax, contourPath } from '../src/plots.ts';
test('linked grids hold the complementary cut coordinates fixed', () => {
  const s = cloneDefaults(), speed = gridFor(s, 'speed'), engagement = gridFor(s, 'engagement');
  assert.equal(speed.samples.length, NX * NY); assert.equal(engagement.samples.length, NX * NY);
  const a = cutAt(speed, s.cut, .5, .5), b = cutAt(engagement, s.cut, .5, .5);
  assert.equal(a.doc, s.cut.doc); assert.equal(a.woc, s.cut.woc);
  assert.equal(b.rpm, s.cut.rpm); assert.equal(b.feed, s.cut.feed);
  assert.equal(a.rpm, 10650); assert.equal(a.feed, 1800); assert.equal(b.doc, 8.25); assert.equal(b.woc, 3);
});
test('selection maps high y to low cut value and avoids zero singularities', () => {
  const s = cloneDefaults(), g = gridFor(s, 'engagement');
  assert.equal(cutAt(g, s.cut, 0, 0).woc, 6);
  assert.equal(cutAt(g, s.cut, 0, 1).woc, .01);
  assert.equal(cutAt(g, s.cut, 0, 1).doc, .01);
});
test('shared scale emphasizes the envelope and handles an empty envelope', () => {
  const s = cloneDefaults(), grids = [gridFor(s, 'speed'), gridFor(s, 'engagement')];
  const max = scaleMax(grids, 'mrr');
  assert.ok(max > 4.32 && max < 20);
  s.limits.deflection = .000000001;
  const none = [gridFor(s, 'speed'), gridFor(s, 'engagement')];
  assert.ok(none.every(g => g.samples.every(r => !r.feasible)));
  assert.ok(Number.isFinite(scaleMax(none, 'mrr')));
});
test('model boundary produces finite contour paths', () => {
  const s = cloneDefaults(), g = gridFor(s, 'speed');
  const path = contourPath(g.samples.map(r => r.limiting.ratio), 1);
  assert.ok(path.startsWith('M')); assert.ok(path.includes('L')); assert.ok(!/NaN|Infinity/.test(path));
});
