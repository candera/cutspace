import { useEffect, useMemo, useRef, useState } from 'react';
import type { PointerEvent, KeyboardEvent } from 'react';
import { ArrowDownToLine, ArrowUpRight, ChevronDown, Crosshair, Gauge, Info, Layers3, RotateCcw, Settings2, SlidersHorizontal, X } from 'lucide-react';
import { availablePower, calculate, clamp, cloneDefaults, constraintInfo, metricValue, metrics, normalize } from './model';
import type { Cut, Metric, Setup } from './model';
import { contourPath, cutAt, gridFor, heatColor, NX, NY, PLOT, scaleMax } from './plots';
import type { Grid } from './plots';

const format = (n: number, digits = 1) => n.toLocaleString('en-US', { maximumFractionDigits: digits, minimumFractionDigits: digits });
const compact = (n: number) => n >= 1000 ? `${format(n / 1000, n % 1000 === 0 ? 0 : 1)}k` : format(n, n < 1 ? 3 : n < 20 ? 1 : 0);
function Field({ label, unit, value, onChange, min = .01, max = 100000, step = .1 }: { label: string; unit?: string; value: number; onChange: (n: number) => void; min?: number; max?: number; step?: number }) {
  const [draft, setDraft] = useState(String(value));
  useEffect(() => setDraft(String(value)), [value]);
  function commit() { const n = Number(draft); if (draft.trim() && Number.isFinite(n)) { const v = clamp(n, min, max); onChange(v); setDraft(String(v)); } else setDraft(String(value)); }
  return <label className="field"><span>{label}</span><div className="number-wrap"><input aria-label={label} type="number" min={min} max={max} step={step} value={draft} onChange={e => setDraft(e.target.value)} onBlur={commit} onKeyDown={e => { if (e.key === 'Enter') e.currentTarget.blur(); }} /><small>{unit}</small></div></label>;
}
function Plot({ grid, setup, metric, max, mode, onSelect }: { grid: Grid; setup: Setup; metric: Metric; max: number; mode: 'heatmap' | 'contours'; onSelect: (c: Cut) => void }) {
  const canvas = useRef<HTMLCanvasElement>(null);
  const [hover, setHover] = useState<Cut | null>(null);
  const speed = grid.kind === 'speed';
  const id = grid.kind;
  const boundaries = useMemo(() => contourPath(grid.samples.map(r => Math.min(1000, r.limiting.ratio)), 1), [grid]);
  const lines = useMemo(() => metric === 'constraint' ? [] : [.2, .4, .6, .8].map(t => ({ path: contourPath(grid.samples.map(r => metricValue(r, metric)), max * t), value: max * t })), [grid, metric, max]);
  useEffect(() => {
    const ctx = canvas.current?.getContext('2d'); if (!ctx) return;
    ctx.clearRect(0, 0, 1280, 780); ctx.save(); ctx.scale(2, 2);
    grid.samples.forEach((r, i) => {
      const x = PLOT.left + i % NX / NX * PLOT.w, y = PLOT.top + Math.floor(i / NX) / NY * PLOT.h;
      ctx.fillStyle = metric === 'constraint' ? constraintInfo[r.limiting.key].color : heatColor(metricValue(r, metric) / max);
      ctx.globalAlpha = metric === 'constraint' ? (r.feasible ? .9 : .4) : mode === 'contours' ? .42 : 1;
      ctx.fillRect(x, y, PLOT.w / NX + .5, PLOT.h / NY + .5);
      if (!r.feasible && metric !== 'constraint') { ctx.globalAlpha = .52; ctx.fillStyle = '#09131e'; ctx.fillRect(x, y, PLOT.w / NX + .5, PLOT.h / NY + .5); }
    });
    ctx.restore(); ctx.globalAlpha = 1;
  }, [grid, metric, max, mode]);
  const sx = (v: number) => PLOT.left + (v - grid.xMin) / (grid.xMax - grid.xMin) * PLOT.w;
  const sy = (v: number) => PLOT.top + (grid.yMax - v) / (grid.yMax - grid.yMin) * PLOT.h;
  const cx = clamp(sx(speed ? setup.cut.rpm : setup.cut.doc), PLOT.left, PLOT.left + PLOT.w);
  const cy = clamp(sy(speed ? setup.cut.feed : setup.cut.woc), PLOT.top, PLOT.top + PLOT.h);
  function pick(e: PointerEvent<SVGRectElement>) {
    const rect = e.currentTarget.getBoundingClientRect();
    return cutAt(grid, setup.cut, clamp((e.clientX - rect.left) / rect.width, 0, 1), clamp((e.clientY - rect.top) / rect.height, 0, 1));
  }
  function key(e: KeyboardEvent<SVGRectElement>) {
    const delta = e.shiftKey ? .05 : .01;
    const x = ((speed ? setup.cut.rpm : setup.cut.doc) - grid.xMin) / (grid.xMax - grid.xMin);
    const y = (grid.yMax - (speed ? setup.cut.feed : setup.cut.woc)) / (grid.yMax - grid.yMin);
    if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.key)) { e.preventDefault(); onSelect(cutAt(grid, setup.cut, clamp(x + (e.key === 'ArrowRight' ? delta : e.key === 'ArrowLeft' ? -delta : 0), 0, 1), clamp(y + (e.key === 'ArrowDown' ? delta : e.key === 'ArrowUp' ? -delta : 0), 0, 1))); }
  }
  const probe = hover ? calculate(hover, setup) : null;
  return <section className="plot-card">
    <div className="plot-heading"><div><span className="eyebrow">{speed ? '01 / SPEED & FEED' : '02 / ENGAGEMENT'}</span><h2>{speed ? 'Find your cutting rhythm' : 'Choose how much to engage'}</h2></div><Crosshair size={19} /></div>
    <p className="held">{speed ? `Holding DOC ${format(setup.cut.doc, 2)} mm · WOC ${format(setup.cut.woc, 2)} mm` : `Holding ${format(setup.cut.rpm, 0)} RPM · ${format(setup.cut.feed, 0)} mm/min`}</p>
    <div className="plot-surface">
      <canvas ref={canvas} width={1280} height={780} aria-hidden="true" />
      <svg viewBox="0 0 640 390" className="plot-svg" aria-label={speed ? 'RPM versus feedrate plot' : 'Axial DOC versus radial WOC plot'}>
        <defs><clipPath id={`clip-${id}`}><rect x={PLOT.left} y={PLOT.top} width={PLOT.w} height={PLOT.h} /></clipPath></defs>
        {[0, .25, .5, .75, 1].map(t => <g key={t} className="plot-grid"><line x1={PLOT.left + t * PLOT.w} x2={PLOT.left + t * PLOT.w} y1={PLOT.top} y2={PLOT.top + PLOT.h} /><line x1={PLOT.left} x2={PLOT.left + PLOT.w} y1={PLOT.top + t * PLOT.h} y2={PLOT.top + t * PLOT.h} /><text x={PLOT.left + t * PLOT.w} y={PLOT.top + PLOT.h + 23} textAnchor="middle">{compact(grid.xMin + t * (grid.xMax - grid.xMin))}</text><text x={PLOT.left - 12} y={PLOT.top + t * PLOT.h + 4} textAnchor="end">{compact(grid.yMax - t * (grid.yMax - grid.yMin))}</text></g>)}
        <text className="axis-title" x={PLOT.left + PLOT.w / 2} y={382} textAnchor="middle">{speed ? 'Spindle speed · RPM' : 'Axial depth of cut · mm'}</text>
        <text className="axis-title" transform="translate(17 180) rotate(-90)" textAnchor="middle">{speed ? 'Feedrate · mm/min' : 'Radial width of cut · mm'}</text>
        <g clipPath={`url(#clip-${id})`}>
          {mode === 'contours' && lines.map((l, i) => <path key={i} d={l.path} fill="none" stroke={heatColor((i + 1) / 5)} strokeWidth="1.6"><title>{format(l.value, 3)} {metrics[metric].unit}</title></path>)}
          <path d={boundaries} fill="none" stroke="#f3f4e9" strokeWidth="1.6" strokeDasharray="5 4" opacity=".88" />
          <line x1={cx} x2={cx} y1={PLOT.top} y2={PLOT.top + PLOT.h} stroke="#fff" opacity=".38" strokeDasharray="3 4" />
          <line x1={PLOT.left} x2={PLOT.left + PLOT.w} y1={cy} y2={cy} stroke="#fff" opacity=".38" strokeDasharray="3 4" />
          <circle cx={cx} cy={cy} r="10" fill="#f5b875" opacity=".16" /><circle cx={cx} cy={cy} r="5.5" fill="#f4bd80" stroke="#fff9ed" strokeWidth="2" />
        </g>
        <rect className="plot-target" aria-label={`${speed ? 'Speed and feed' : 'DOC and WOC'} selection; use arrow keys, Shift for larger steps`} role="group" tabIndex={0} x={PLOT.left} y={PLOT.top} width={PLOT.w} height={PLOT.h} fill="transparent" onKeyDown={key}
          onPointerDown={e => { e.currentTarget.setPointerCapture(e.pointerId); onSelect(pick(e)); }}
          onPointerMove={e => { const c = pick(e); setHover(c); if (e.buttons === 1) onSelect(c); }} onPointerUp={e => { if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId); }} onPointerLeave={() => setHover(null)} />
      </svg>
    </div>
    <div className="plot-foot">{probe && hover ? <><span>{speed ? `${format(hover.rpm, 0)} RPM / ${format(hover.feed, 0)} mm/min` : `${format(hover.doc, 2)} DOC / ${format(hover.woc, 2)} WOC`}</span><span>{metric === 'constraint' ? constraintInfo[probe.limiting.key].label : `${format(metricValue(probe, metric), metric === 'chip' ? 4 : 1)} ${metrics[metric].unit}`}</span></> : <><span><span className="tiny-cross">+</span> Click or drag to move the cutting point</span><span>Linked view <ArrowUpRight size={13} /></span></>}</div>
  </section>;
}
function Curve({ setup }: { setup: Setup }) {
  const m = setup.machine, r = calculate(setup.cut, setup);
  const points = Array.from({ length: 50 }, (_, i) => { const n = 100 + i / 49 * (m.rpmMax - 100); return `${28 + i / 49 * 204},${88 - availablePower(n, m) / m.power * 66}`; }).join(' ');
  return <div className="curve"><div><span>Usable output estimate</span><strong>{format(r.capacity, 0)} W <small>at selection</small></strong></div><svg viewBox="0 0 260 113" role="img" aria-label="Estimated constant torque then constant power curve"><line x1="28" x2="232" y1="88" y2="88" stroke="#c5d6ce"/><polyline points={points} fill="none" stroke="#227c64" strokeWidth="2.5"/><circle cx={28 + clamp((setup.cut.rpm - 100) / (m.rpmMax - 100), 0, 1) * 204} cy={88 - r.capacity / m.power * 66} r="4" fill="#d58d47"/><text x="26" y="105">0</text><text x="232" y="105" textAnchor="end">{compact(m.rpmMax)} RPM</text><text x="26" y="15">{format(m.power, 0)} W</text></svg><p>Constant torque → constant power, with {format((1 - m.utilization) * 100, 0)}% reserve.</p></div>;
}
function App() {
  const [setup, setSetup] = useState<Setup>(cloneDefaults);
  const [metric, setMetric] = useState<Metric>('mrr');
  const [mode, setMode] = useState<'heatmap' | 'contours'>('heatmap');
  const [showModel, setShowModel] = useState(false);
  const [exported, setExported] = useState(false);
  const dialog = useRef<HTMLDialogElement>(null);
  const result = useMemo(() => calculate(setup.cut, setup), [setup]);
  const grids = useMemo(() => [gridFor(setup, 'speed'), gridFor(setup, 'engagement')], [setup]);
  const max = useMemo(() => scaleMax(grids, metric), [grids, metric]);
  const hasEnvelope = grids.some(g => g.samples.some(r => r.feasible));
  const patch = <K extends keyof Setup>(group: K, value: Partial<Setup[K]>) => setSetup(s => normalize({ ...s, [group]: { ...s[group], ...value } }));
  const select = (cut: Cut) => setSetup(s => ({ ...s, cut }));
  useEffect(() => { if (showModel) dialog.current?.showModal(); else dialog.current?.close(); }, [showModel]);
  function download() {
    const blob = new Blob([JSON.stringify({ app: 'cutspace', version: 1, warning: 'Illustrative model. All limits unvalidated. Not a machining recommendation.', setup, calculated: result }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob), a = document.createElement('a'); a.href = url; a.download = 'cutspace-setup.json'; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000); setExported(true); setTimeout(() => setExported(false), 2000);
  }
  const violations = result.constraints.filter(c => c.ratio > 1);
  return <div className="app">
    <header className="topbar"><a className="brand" href="#"><span className="brand-mark"><Layers3 size={23}/></span>cutspace<span className="brand-dot">.</span></a><span className="app-subtitle">MILLING EXPLORER</span><div className="header-actions"><span className="prototype"><i/> LOCAL PROTOTYPE</span><button className="quiet" onClick={() => setShowModel(true)}><Info size={16}/> Model & assumptions</button><button className="export" onClick={download}><ArrowDownToLine size={15}/>{exported ? 'Exported' : 'Export setup'}</button></div></header>
    <div className="workspace">
      <aside className="sidebar">
        <div className="sidebar-title"><span><SlidersHorizontal size={17}/> Setup</span><button className="icon-button" title="Reset illustrative setup" aria-label="Reset illustrative setup" onClick={() => setSetup(cloneDefaults())}><RotateCcw size={16}/></button></div>
        <details open className="config-section"><summary><span>01 <b>Cutting tool</b></span><ChevronDown size={15}/></summary><p className="section-note">Flat end mill · assumed carbide</p><div className="field-grid">
          <Field label="Diameter" unit="mm" value={setup.tool.diameter} min={.5} max={50} onChange={diameter => patch('tool', {diameter})}/>
          <Field label="Flutes" value={setup.tool.flutes} min={1} max={12} step={1} onChange={flutes => patch('tool', {flutes})}/>
          <Field label="Stickout" unit="mm" value={setup.tool.stickout} min={1} max={200} onChange={stickout => patch('tool', {stickout})}/>
          <Field label="Flute length" unit="mm" value={setup.tool.fluteLength} min={.1} max={100} onChange={fluteLength => patch('tool', {fluteLength})}/>
        </div><div className="tool-stat"><span>L/D ratio</span><b>{format(setup.tool.stickout / setup.tool.diameter, 1)}×</b><span className="estimate">GEOMETRY</span></div></details>
        <details open className="config-section"><summary><span>02 <b>Material</b></span><ChevronDown size={15}/></summary><div className="material-card"><span className="material-swatch"/><div><b>6061 aluminum</b><small>Illustrative cutting-force model</small></div></div><Field label="Specific cutting force" unit="N/mm²" value={setup.material.kc} min={50} max={10000} step={50} onChange={kc => patch('material', {kc})}/><p className="section-note">Editable effective Kc, not a certified material constant.</p></details>
        <details open className="config-section"><summary><span>03 <b>Machine</b></span><ChevronDown size={15}/></summary><label className="field"><span>Profile name</span><input className="profile-input" aria-label="Profile name" value={setup.machine.name} onChange={e => patch('machine', {name: e.target.value})}/></label><div className="assumption-note">All values below are placeholders, including RPM bounds. No manufacturer specs.</div><div className="field-grid">
          <Field label="Min RPM" value={setup.machine.rpmMin} min={100} max={99900} step={100} onChange={rpmMin => patch('machine', {rpmMin})}/>
          <Field label="Max RPM" value={setup.machine.rpmMax} min={200} max={100000} step={100} onChange={rpmMax => patch('machine', {rpmMax})}/>
          <Field label="Power plateau" unit="W" value={setup.machine.power} min={1} max={50000} step={10} onChange={power => patch('machine', {power})}/>
          <Field label="Torque plateau" unit="Nm" value={setup.machine.torque} min={.01} max={100} step={.01} onChange={torque => patch('machine', {torque})}/>
          <Field label="Max feedrate" unit="mm/min" value={setup.machine.feedMax} min={10} max={50000} step={100} onChange={feedMax => patch('machine', {feedMax})}/>
          <Field label="Usable output" unit="%" value={setup.machine.utilization * 100} min={1} max={100} step={1} onChange={v => patch('machine', {utilization: v / 100})}/>
        </div><Curve setup={setup}/></details>
        <details className="config-section"><summary><span>04 <b>Limits & model</b></span><ChevronDown size={15}/></summary><p className="section-note">User-set limits · every threshold is unvalidated.</p><div className="field-grid">
          <Field label="Min chip thickness" unit="mm" value={setup.limits.chipMin} min={.0001} max={.5} step={.001} onChange={chipMin => patch('limits', {chipMin})}/>
          <Field label="Max chip thickness" unit="mm" value={setup.limits.chipMax} min={.001} max={1} step={.001} onChange={chipMax => patch('limits', {chipMax})}/>
          <Field label="Deflection limit" unit="µm" value={setup.limits.deflection} min={.1} max={1000} step={1} onChange={deflection => patch('limits', {deflection})}/>
          <Field label="Max surface speed" unit="m/min" value={setup.limits.surfaceMax} min={1} max={5000} step={10} onChange={surfaceMax => patch('limits', {surfaceMax})}/>
          <Field label="Elastic modulus" unit="GPa" value={setup.tool.modulus} min={10} max={1000} step={10} onChange={modulus => patch('tool', {modulus})}/>
          <Field label="Effective stiffness" unit="× solid" value={setup.tool.stiffness} min={.05} max={1} step={.05} onChange={stiffness => patch('tool', {stiffness})}/>
          <Field label="Power allowance" unit="×" value={setup.material.powerFactor} min={1} max={5} step={.05} onChange={powerFactor => patch('material', {powerFactor})}/>
          <Field label="Force allowance" unit="×" value={setup.material.forceFactor} min={1} max={5} step={.05} onChange={forceFactor => patch('material', {forceFactor})}/>
        </div></details>
        <div className="sidebar-bottom"><span className="mini-mark">C/</span><p>Explore the tradeoffs.<br/>Validate at the machine.</p></div>
      </aside>
      <main>
        <section className="intro"><div><div className="eyebrow">THE OPERATING ENVELOPE</div><h1>Find room to cut.</h1><p>Explore the balance between speed, engagement and machine capacity.</p></div><div className="unit-chip"><span/> METRIC <span className="muted">/ mm</span></div></section>
        <div className="context-row"><span><i className="green-dot"/> {setup.material.name}</span><span>Ø{format(setup.tool.diameter, 1)} mm · {setup.tool.flutes} flutes</span><span>{setup.machine.name}</span><span className="context-end">Illustrative setup</span></div>
        <section className="visual-workspace">
          <div className="view-toolbar"><div className="metric-select"><label htmlFor="metric"><Settings2 size={15}/> Color by</label><select id="metric" value={metric} onChange={e => { const next = e.target.value as Metric; setMetric(next); if (next === 'constraint') setMode('heatmap'); }}>{Object.entries(metrics).map(([key, m]) => <option key={key} value={key}>{m.label}</option>)}</select><span className="kind-label">{metrics[metric].kind}</span></div><div className="segmented" aria-label="Plot appearance"><button aria-pressed={mode === 'heatmap'} onClick={() => setMode('heatmap')}>Heatmap</button><button aria-pressed={mode === 'contours'} disabled={metric === 'constraint'} onClick={() => setMode('contours')}>Contours</button></div></div>
          <div className="plots">{grids.map(grid => <Plot key={grid.kind} grid={grid} setup={setup} metric={metric} max={max} mode={mode} onSelect={select}/>)}</div>
          <div className="legend-row">{metric === 'constraint' ? <div className="category-legend">{Object.entries(constraintInfo).map(([key, c]) => <span key={key}><i style={{background: c.color}}/>{c.label}</span>)}</div> : <div className="scale-legend"><span>{metrics[metric].label}</span><div><div className="gradient"/><div className="scale-labels"><span>0</span><span>{format(max, metric === 'chip' ? 3 : 1)} {metrics[metric].unit}</span></div></div></div>}<div className="boundary-key"><span className="dashed-line"/> Model boundary <span className="dim-box"/> Outside limits</div></div>
          <p className="plot-explanation">{metric === 'constraint' ? 'Color identifies the highest limit ratio, including inside the envelope. Dimmed regions exceed at least one limit.' : `Both plots share a linear ${hasEnvelope ? 'within-limit' : 'full-grid'} color scale${mode === 'contours' ? '; contour lines mark 20%, 40%, 60% and 80% of the scale' : ''}. Values above the scale saturate. Dimmed regions exceed at least one configured limit.`} The boundary is sampled, not an exact solver.</p>
        </section>
        <section className="selection-panel"><div className="selection-heading"><h2><Crosshair size={18}/> Selected cutting point</h2><span className={`status ${result.feasible ? 'inside' : 'outside'}`}>{result.feasible ? 'Within modeled limits' : `${violations.length} modeled limit${violations.length === 1 ? '' : 's'} exceeded`}</span></div><div className="cut-controls">{([
          {key: 'rpm', label: 'Spindle speed', unit: 'RPM', min: 100, max: setup.machine.rpmMax * 1.1, step: 100},
          {key: 'feed', label: 'Feedrate', unit: 'mm/min', min: 1, max: setup.machine.feedMax * 1.2, step: 10},
          {key: 'doc', label: 'Axial DOC', unit: 'mm', min: .01, max: setup.tool.fluteLength * 1.1, step: .01},
          {key: 'woc', label: 'Radial WOC', unit: 'mm', min: .01, max: setup.tool.diameter, step: .01},
        ] as const).map(c => <div key={c.key}><Field label={c.label} unit={c.unit} min={c.min} max={c.max} step={c.step} value={setup.cut[c.key]} onChange={n => patch('cut', {[c.key]: n})}/><input aria-label={`${c.label} slider`} type="range" min={c.min} max={c.max} step={c.key === 'rpm' || c.key === 'feed' ? 1 : c.step} value={setup.cut[c.key]} onChange={e => patch('cut', {[c.key]: Number(e.target.value)})}/></div>)}</div>
          <div className="output-grid">{[
            {label: 'Surface speed', value: format(result.surface, 1), unit: 'm/min', type: 'Computed'},
            {label: 'Feed per tooth', value: format(result.chip, 4), unit: 'mm/tooth', type: 'Computed'},
            {label: 'Max chip thickness', value: format(result.chipMax, 4), unit: 'mm', type: 'Ideal geometry'},
            {label: 'Material removal', value: format(result.mrr, 2), unit: 'cm³/min', type: 'Computed'},
            {label: 'Spindle power', value: format(result.power, 1), unit: 'W', type: 'Estimated'},
            {label: 'Spindle torque', value: format(result.torque, 3), unit: 'Nm', type: 'Estimated'},
            {label: 'Tool deflection', value: format(result.deflection, 1), unit: 'µm', type: 'Estimated'},
            {label: 'Chip thinning', value: format(1 / result.thinning, 2) + '×', unit: 'feed multiplier', type: 'Ideal geometry'},
          ].map(o => <div className="output" key={o.label}><span>{o.label}</span><strong>{o.value} <small>{o.unit}</small></strong><em className={o.type === 'Estimated' ? 'estimated' : ''}>{o.type}</em></div>)}</div>
          <div className="thinning-note">At {format(setup.cut.woc / setup.tool.diameter * 100, 1)}% radial engagement, maximum chip thickness is {format(result.thinning * 100, 0)}% of feed/tooth. The multiplier is informational; feed is not automatically increased.</div>
        </section>
        <div className="bottom-grid"><section className="constraint-card"><div className="card-title"><h2><Gauge size={17}/> What sets the boundary</h2><span>Selected point</span></div>{result.constraints.slice(0, 4).map(c => <div className="constraint-row" key={c.key}><div><span>{constraintInfo[c.key].label}</span><b className={c.ratio > 1 ? 'over' : ''}>{format(c.ratio * 100, 0)}%</b></div><div className="bar-track"><i style={{width: `${Math.min(100, c.ratio * 100)}%`, background: c.ratio > 1 ? '#bf6847' : constraintInfo[c.key].color}}/></div></div>)}<p>100% reaches a configured limit. Low-chip and minimum-RPM ratios increase as the selected value decreases.</p></section><section className="notes-card"><div className="card-title"><h2><Info size={17}/> Read this envelope as a model</h2></div><div className="warning-list" aria-live="polite">{violations.length ? violations.map(c => <p className="warning" key={c.key}><b>{constraintInfo[c.key].label}</b> exceeds the configured threshold ({format(c.ratio, 2)}×).</p>) : <p className="positive">This point passes the configured checks. These limits have not been validated for your setup.</p>}</div><p>Static tool bending only. Chatter, workholding, runout, chip evacuation, tool wear and machine compliance are not predicted.</p><button className="text-link" onClick={() => setShowModel(true)}>Inspect the assumptions <ArrowUpRight size={15}/></button></section></div>
        <footer><span>CUTSPACE <b>/</b> A practical space for cutting tradeoffs</span><span>Prototype 0.1 · No cutting recommendation</span></footer>
      </main>
    </div>
    <dialog ref={dialog} onCancel={() => setShowModel(false)} onClick={e => { if (e.target === e.currentTarget) setShowModel(false); }}><div className="dialog-header"><div><span className="eyebrow">MODEL NOTES / v0.1</span><h2>Useful estimates. Visible assumptions.</h2></div><button className="icon-button" aria-label="Close model notes" onClick={() => setShowModel(false)}><X/></button></div><div className="dialog-content"><p>Cutspace explores straight peripheral milling with a flat end mill and constant engagement. A point inside the envelope passes only the configured mathematical checks. It is not a proven safe or chatter-free cut.</p><h3>Computed geometry</h3><p>Surface speed = π × diameter × RPM / 1000. Feed/tooth = feedrate / (RPM × flutes). MRR = DOC × WOC × feedrate / 1000, in cm³/min.</p><p>For radial engagement r = WOC / diameter below 50%, maximum chip thickness = feed/tooth × 2√(r(1−r)). At 50–100%, the factor is 1. Its inverse is the displayed chip-thinning multiplier. This assumes ideal cylindrical cutting geometry and excludes runout and edge effects.</p><h3>Estimated power & torque</h3><p>Power (W) = MRR × effective Kc / 60 × power allowance. Torque (Nm) = power × 60 / (2π × RPM). Kc starts at an illustrative 1000 N/mm²; the default 1.25× allowance adds margin but cannot guarantee conservatism. Power is mechanical spindle demand, not wall power.</p><p>Available output = min(power plateau, torque plateau × 2π × RPM / 60) × usable-output fraction. Every machine value is illustrative, including the DMC2 Mini name and RPM range. Replace them with verified data.</p><h3>Estimated static bending</h3><p>Engagement angle φ = acos(1−2r). Estimated simultaneously engaged teeth = max(1, ceil(flutes × φ / 2π)). Force = Kc × DOC × maximum chip thickness × engaged teeth × force allowance. This sums peak loads without helix averaging.</p><p>Tip deflection = F × stickout³ / (3EI), with E converted from GPa and I = stiffness factor × πD⁴/64. Defaults use E = 600 GPa, stiffness factor = 0.45 and force allowance = 1.3. These are uncalibrated assumptions, not a flute-section analysis. Holder and machine flexibility are absent.</p><h3>What the boundary means</h3><p>Limits test chip-thickness band, power, torque, static deflection, surface speed, machine RPM/feed and tool engagement (DOC no greater than flute length or stickout; WOC no greater than diameter). The highest normalized ratio sets the limiting constraint. Every ratio must be ≤ 1. Default limits are demonstration thresholds, not tool-maker recommendations.</p><p>The sampled grids can miss narrow regions. Power and force estimates omit chip-size effects, entry transients and dynamic forces. No chatter or stability-lobe prediction is made. No automatic optimization or machine control is provided.</p><h3>References & extension points</h3><p><a href="https://www.sandvik.coromant.com/en-gb/knowledge/machining-formulas-definitions/milling-formulas-definitions" target="_blank" rel="noreferrer">Sandvik Coromant: milling formulas</a> · <a href="https://www.harveyperformance.com/in-the-loupe/combat-chip-thinning/" target="_blank" rel="noreferrer">Harvey Performance: radial chip thinning</a> · <a href="https://live.ocw.mit.edu/courses/1-050-solid-mechanics-fall-2004/f9a4d5764b9b0f51ffaacbdf69f7aed8_emech10_04.pdf" target="_blank" rel="noreferrer">MIT: beam mechanics</a></p><p>The README documents units, defaults, tests and extension points. The pure calculation module is <code>src/model.ts</code>. Use measured spindle curves, calibrated force coefficients and actual tool geometry before treating the estimates as process guidance.</p></div></dialog>
  </div>;
}
export default App;
