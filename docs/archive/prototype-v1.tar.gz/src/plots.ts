import { contours } from 'd3-contour';
import { calculate, metricValue } from './model.ts';
import type { Setup, Cut, Result, Metric } from './model.ts';
export const NX = 80, NY = 54;
export const PLOT = { width: 640, height: 390, left: 66, top: 26, w: 548, h: 308 };
export interface Grid { samples: Result[]; xMin: number; xMax: number; yMin: number; yMax: number; kind: 'speed' | 'engagement' }
export function gridFor(s: Setup, kind: Grid['kind']): Grid {
  const speed = kind === 'speed';
  const grid: Grid = { samples: [], kind,
    xMin: speed ? Math.max(100, s.machine.rpmMin * 0.5) : 0,
    xMax: speed ? s.machine.rpmMax * 1.1 : s.tool.fluteLength * 1.1,
    yMin: 0, yMax: speed ? s.machine.feedMax * 1.2 : s.tool.diameter,
  };
  for (let j = 0; j < NY; j++) for (let i = 0; i < NX; i++) {
    grid.samples.push(calculate(cutAt(grid, s.cut, (i + .5) / NX, (j + .5) / NY), s));
  }
  return grid;
}
export function cutAt(g: Grid, c: Cut, x: number, y: number): Cut {
  const a = g.xMin + x * (g.xMax - g.xMin), b = g.yMax - y * (g.yMax - g.yMin);
  return g.kind === 'speed' ? { ...c, rpm: Math.max(100, Math.round(a)), feed: Math.max(1, Math.round(b)) } : { ...c, doc: Math.max(.01, Math.round(a * 100) / 100), woc: Math.max(.01, Math.round(b * 100) / 100) };
}
export function contourPath(values: number[], threshold: number) {
  const shape = contours().size([NX, NY]).thresholds([threshold])(values)[0];
  if (!shape) return '';
  return shape.coordinates.flatMap(poly => poly.map(ring => ring.map((p, i) => `${i ? 'L' : 'M'}${(PLOT.left + p[0] / NX * PLOT.w).toFixed(2)},${(PLOT.top + p[1] / NY * PLOT.h).toFixed(2)}`).join('') + 'Z')).join('');
}
export function scaleMax(grids: Grid[], metric: Metric): number {
  if (metric === 'constraint') return 1;
  const all = grids.flatMap(g => g.samples);
  const feasible = all.filter(r => r.feasible);
  return Math.max(0.000001, ...(feasible.length ? feasible : all).map(r => metricValue(r, metric))); 
}
export function heatColor(value: number): string {
  const stops = [[23, 43, 58], [31, 87, 100], [58, 144, 139], [159, 199, 150], [236, 209, 133]];
  const v = Math.max(0, Math.min(1, value)) * (stops.length - 1), i = Math.min(stops.length - 2, Math.floor(v)), f = v - i;
  return `rgb(${stops[i].map((a, k) => Math.round(a + (stops[i + 1][k] - a) * f)).join(',')})`;
}
