/** All lengths are mm; time is min unless stated. See README for provenance and limitations. */
export interface Tool { diameter: number; flutes: number; stickout: number; fluteLength: number; modulus: number; stiffness: number }
export interface Material { name: string; kc: number; powerFactor: number; forceFactor: number }
export interface Machine { name: string; rpmMin: number; rpmMax: number; feedMax: number; power: number; torque: number; utilization: number }
export interface Limits { chipMin: number; chipMax: number; deflection: number; surfaceMax: number }
export interface Cut { rpm: number; feed: number; doc: number; woc: number }
export interface Setup { tool: Tool; material: Material; machine: Machine; limits: Limits; cut: Cut }
export const defaults: Setup = {
  tool: { diameter: 6, flutes: 3, stickout: 20, fluteLength: 15, modulus: 600, stiffness: 0.45 },
  material: { name: '6061 aluminum', kc: 1000, powerFactor: 1.25, forceFactor: 1.3 },
  machine: { name: 'DMC2 Mini · illustrative', rpmMin: 3000, rpmMax: 18000, feedMax: 3000, power: 250, torque: 0.3, utilization: 0.75 },
  limits: { chipMin: 0.008, chipMax: 0.055, deflection: 25, surfaceMax: 450 },
  cut: { rpm: 10000, feed: 1200, doc: 3, woc: 1.2 },
};
export const cloneDefaults = (): Setup => structuredClone(defaults);
export type ConstraintKey = 'chipHigh' | 'chipLow' | 'power' | 'torque' | 'deflection' | 'surface' | 'rpm' | 'feed' | 'geometry';
export const constraintInfo: Record<ConstraintKey, { label: string; color: string }> = {
  chipHigh: { label: 'Chip thickness high', color: '#dc9e61' },
  chipLow: { label: 'Chip thickness low', color: '#a4a9df' },
  power: { label: 'Spindle power', color: '#e5c26b' },
  torque: { label: 'Spindle torque', color: '#db8dab' },
  deflection: { label: 'Tool deflection', color: '#81b4e0' },
  surface: { label: 'Surface speed', color: '#9fc475' },
  rpm: { label: 'RPM range', color: '#c0a48f' },
  feed: { label: 'Machine feed', color: '#6bc4c5' },
  geometry: { label: 'Tool engagement', color: '#cba8e2' },
};
export interface Constraint { key: ConstraintKey; ratio: number }
export function availablePower(rpm: number, m: Machine): number {
  // Mechanical spindle output, not electrical input. Constant torque then constant power.
  return Math.min(m.power, m.torque * 2 * Math.PI * rpm / 60) * m.utilization;
}
export function calculate(c: Cut, s: Setup) {
  const { tool: t, material: mat, machine: m, limits: l } = s;
  const surface = Math.PI * t.diameter * c.rpm / 1000;
  const chip = c.feed / (c.rpm * t.flutes);
  const engagement = Math.min(1, Math.max(0, c.woc / t.diameter));
  const thinning = engagement < 0.5 ? 2 * Math.sqrt(engagement * (1 - engagement)) : 1;
  const chipMax = chip * thinning;
  const mrr = c.doc * c.woc * c.feed / 1000;
  const power = mrr * mat.kc / 60 * mat.powerFactor; // W: cm³/min * 1000 / 60000
  const torque = power * 60 / (2 * Math.PI * c.rpm);
  const capacity = availablePower(c.rpm, m);
  const phi = Math.acos(1 - 2 * engagement);
  const teeth = Math.max(1, Math.ceil(t.flutes * phi / (2 * Math.PI)));
  // Conservative simultaneous peak tooth loads; no helix averaging or dynamic prediction.
  const force = c.doc === 0 || c.woc === 0 ? 0 : mat.kc * c.doc * chipMax * teeth * mat.forceFactor;
  const inertia = Math.PI * t.diameter ** 4 / 64 * t.stiffness;
  const deflection = force * t.stickout ** 3 / (3 * t.modulus * 1000 * inertia) * 1000; // µm
  const constraints: Constraint[] = [
    { key: 'chipHigh', ratio: chipMax / l.chipMax },
    { key: 'chipLow', ratio: chipMax > 0 ? l.chipMin / chipMax : Infinity },
    { key: 'power', ratio: power / (m.power * m.utilization) },
    { key: 'torque', ratio: torque / (m.torque * m.utilization) },
    { key: 'deflection', ratio: deflection / l.deflection },
    { key: 'surface', ratio: surface / l.surfaceMax },
    { key: 'rpm', ratio: Math.max(m.rpmMin / c.rpm, c.rpm / m.rpmMax) },
    { key: 'feed', ratio: c.feed / m.feedMax },
    { key: 'geometry', ratio: Math.max(c.woc / t.diameter, c.doc / t.fluteLength, c.doc / t.stickout) },
  ].sort((a, b) => b.ratio - a.ratio) as Constraint[];
  return { surface, chip, chipMax, thinning, mrr, power, torque, capacity, force, deflection, constraints, limiting: constraints[0], feasible: constraints[0].ratio <= 1 };
}
export type Result = ReturnType<typeof calculate>;
export type Metric = 'mrr' | 'power' | 'chip' | 'deflection' | 'constraint';
export const metrics: Record<Metric, {label: string; unit: string; kind: string}> = {
  mrr: { label: 'Material removal', unit: 'cm³/min', kind: 'Computed' },
  power: { label: 'Spindle power', unit: 'W', kind: 'Estimated' },
  chip: { label: 'Feed per tooth', unit: 'mm/tooth', kind: 'Computed' },
  deflection: { label: 'Tool deflection', unit: 'µm', kind: 'Estimated' },
  constraint: { label: 'Limiting constraint', unit: '', kind: 'Unvalidated limits' },
};
export const metricValue = (r: Result, metric: Metric) => metric === 'constraint' ? r.limiting.ratio : r[metric];
export const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));
export function normalize(s: Setup): Setup {
  // Called only on UI edits. Keep geometry and numeric inputs finite and consistent.
  const n = structuredClone(s);
  n.machine.rpmMax = Math.max(n.machine.rpmMin + 100, n.machine.rpmMax);
  n.limits.chipMax = Math.max(n.limits.chipMin + 0.001, n.limits.chipMax);
  n.tool.flutes = Math.round(n.tool.flutes);
  n.cut.rpm = clamp(n.cut.rpm, 100, n.machine.rpmMax * 1.1);
  n.cut.feed = clamp(n.cut.feed, 1, n.machine.feedMax * 1.2);
  n.cut.doc = clamp(n.cut.doc, 0.01, Math.max(n.tool.fluteLength, n.tool.stickout) * 1.1);
  n.cut.woc = clamp(n.cut.woc, 0.01, n.tool.diameter);
  return n;
}
